// const AWS = require('aws-sdk')
// const documentDB = new AWS.DynamoDB.DocumentClient()

// const execute = async (command) => {
//   if (!command.players) return

//   const players = command.players
//   if (players.add) {
//     return addPlayers(tournament.create)
//   }
//   if (tournament.current) {
//     return setCurrentTournament(tournament.current)
//   }
// }
