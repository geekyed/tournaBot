# tournaBot
Tourament bot Lambda for slack
